###r Script for fragstats tutorial 5
#K. McGarigal 15 January 2015


#set working directory
setwd('c:/work/fragstats/tutorial/tutorial_5')

#write fragstats batch file
temp<-paste('c:\\work\\fragstats\\tutorial\\tutorial_5\\reg78b.tif','x','999',
            'x','x',1,'x','IDF_GeoTIFF',sep=',')
write.table(temp,file='geotiffbatch.fbt',quote=FALSE,row.names=FALSE,col.names=FALSE)

#execute fragstats
system('frg -m fragmodelR.fca -b geotiffbatch.fbt -o c:\\work\\fragstats\\tutorial\\tutorial_5\\fragout')

#read in fragstats output
frag.patch<-read.csv('fragout.patch',header=TRUE,strip.white=TRUE,na.strings='N/A')
frag.class<-read.csv('fragout.class',header=TRUE,strip.white=TRUE,na.strings='N/A')
frag.land<-read.csv('fragout.land',header=TRUE,strip.white=TRUE,na.strings='N/A')

#load Rfrag package
library(Rfrag)

frag.combine('c:/work/fragstats/tutorial/tutorial_5/',inland='fragout.land',
    inclass='fragout.class')

##################################################################################
#ascii grid

#read ascii grid
m<-as.matrix(read.table('reg78b.asc'))

#write ascii grid
write.table(m,file='reg78b.asc',row.names=FALSE,col.names=FALSE)

#write fragstats batch file
temp<-paste('c:\\work\\fragstats\\tutorial\\tutorial_5\\reg78b.asc','50','999',
            dim(m)[1],dim(m)[2],1,'9999','IDF_ASCII',sep=',')
write.table(temp,file='ascibatch.fbt',quote=FALSE,row.names=FALSE,col.names=FALSE)

#execute fragstats
system('frg -m fragmodelR.fca -b ascibatch.fbt -o c:\\work\\fragstats\\tutorial\\tutorial_5\\fragout')

#read in fragstats output
frag.patch<-read.csv('fragout.patch',header=TRUE,strip.white=TRUE,na.strings='N/A')
frag.class<-read.csv('fragout.class',header=TRUE,strip.white=TRUE,na.strings='N/A')
frag.land<-read.csv('fragout.land',header=TRUE,strip.white=TRUE,na.strings='N/A')







