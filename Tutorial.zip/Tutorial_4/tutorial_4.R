###R script for fragstats tutorial 4
#K. McGarigal 22 April 2012


#load raster library
library(raster)

#set working directory to your directory
setwd('c:/work/fragstats/tutorial/tutorial_4/reg78b.asc_mw1')

#read ascii grid
m<-as.matrix(read.table('gyrate_am.asc',na.strings='-999'))

#convert matrix to raster object
m<-raster(m)

#plot grid
plot(m)


###same thing but using image function in graphics library

#set working directory
setwd('c:/work/fragstats/tutorial/tutorial_4/reg78b.asc_mw1')

#read ascii grid
m<-as.matrix(read.table('gyrate_am.asc',na.strings='-999'))

#plot the image
image(t(m)[,nrow(m):1],asp=1,col=terrain.colors(10))
