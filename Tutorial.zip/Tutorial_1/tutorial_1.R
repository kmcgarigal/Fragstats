###R script for fragstats tutorial 1
#K. McGarigal 22 April 2012


#set working directory to your directory
setwd('c:/work/fragstats/tutorial/tutorial_1')

#read ascii grid
m<-as.matrix(read.table('reg78b.asc'))

#identify unique class values
uv<-sort(unique(as.vector(m)))

#create breaks for assigning colors to class values (breaks are at min -1, midpoints and max +1)
my.breaks<-(c(min(uv)-2, uv) + c(uv, max(uv)+2 ))/2

#create color legend for plot
my.colors<-c('gray','lightskyblue','lightgreen','lightpink','lightyellow','yellow','purple','slateblue','green','skyblue','black')
if(length(my.colors) != length(uv)) stop("You need a color for every unique value")

# print the color associated with each value
data.frame(code=uv,color=my.colors) 

#plot the image
image(t(m)[,nrow(m):1],asp=1,breaks=my.breaks,col=my.colors)
