import arcpy
arcpy.env.workspace = "C:/work/fragstats/tutorial/tutorial_6"
arcpy.Buffer_analysis("pointsran", "C:/work/fragstats/tutorial/tutorial_6/pointsran_buf","5000","FULL","FLAT","NONE","POINTID") 
